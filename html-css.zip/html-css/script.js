document.write("Hello JavaScript!!");

